
$(function (){
    var t;
    t=setInterval(generar_contenido, 300000);
	generar_contenido();
});   

function generar_contenido(){ // genera contenido

	var ahora = new Date();
	var hoy; //selecciona las actividades del dia en la parrilla
	hoy = dia_semana(ahora);
	$("#dia").html("Actividades " + hoy + ", " + ahora.getDate())  ;	
	var avisos  = $("#contenido"); 	
	if (ahora.getHours()>21 || ahora.getHours()<8){avisos.html("<h2>Cerrado ahora</h2");};
	
		parrilla.forEach(function(elem,i) {
			actividad = parrilla[i].acti_1;

			if (parrilla[i].dia == hoy && actividad){//evaluamos si para un dia dado hay actividad en la hora considerada
				var hora, a, h, e, f, m, actividad, pinta, reserva, sala, mensaje;
				hora = parrilla[i].hora;				
				h = parseInt(hora.substring(0, 2));
				m = parseInt(hora.substring(3));
				a = ahora.getFullYear();
				e = ahora.getMonth();
				f = ahora.getDate();
				var momento   = new Date(a, e, f, h, m, 0, 0);	
		
				if (ahora.getTime() < momento.getTime()) {//actividades posteriores a la hora actual
					reserva   = parrilla[i].res;
					sala      = parrilla[i].sala;			
					if (actividad=="Balance" || actividad=="Pilates" || actividad=="Zumba" || actividad=="Fitness"){
							pinta = "mio";
					}else{
							pinta = "";
					}
				mensaje = '&emsp;' + hora + '&nbsp;' + actividad;	
				(sala) ? mensaje = mensaje + '&nbsp;-&nbsp;' + sala : null;			
				(reserva) ? mensaje = mensaje + '&nbsp;&#42' : null;
				avisos.append("<button class='" + pinta + "'>" + mensaje + '</button>');
				} // viene de ahora.getTime()
			} // fin del condicionante de parrilla /dia 
		}); // cierre del foreach que recorre la parrilla 
};




function dia_semana(d){

	switch (d.getDay()){
		case 0:
			hoy = "domingo";
			break;
		case 1:
			hoy = "lunes";
			break;		
		case 2:
			hoy = "martes";
			break;
		case 3:
			hoy = "miércoles";
			break;
		case 4:
			hoy = "jueves";
			break;		
		case 5:
			hoy = "viernes";
			break;
		case 6:
			hoy = "sabado";
			break;
	}
	return (hoy);
}

